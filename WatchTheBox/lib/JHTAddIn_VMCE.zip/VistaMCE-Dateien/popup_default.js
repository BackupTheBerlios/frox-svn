function chatWindow() 
{ 
window.open('http://www.mce-community.de/forum/mceChat/flashchat.php','jav','width=600,height=400,resizable=no,directories=no,status=no,menubar=no,toolbar=no,location=no,top=100,left=100,screenX=100,screenY=100'); 
}