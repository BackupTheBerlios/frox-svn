/**
* JS Language File: German
*/

var message_pop_up_lang =
{
	// DEFAULT
	'error'			   : 'Es ist ein Fehler aufgetreten',
	'no_permission'	   : 'Du hast keine Berechtigungen f&uuml;r diese Aktion',
	'cannot_cont'	   : 'Kann mit dieser Anfrage nicht fortfahren',
	'settings_updated' : 'Einstellungen aktualisiert',
	
	// Custom errors:
	'pp_date_error'     : 'Das Datum muss g&uuml;ltig sein',
	'pp_comment_error'  : 'Du kannst keine leeren Kommentare schreiben',
	'pp_friend_exist'   : 'Dieses Mitglied scheint nicht zu existieren',
	'pp_friend_already' : 'Du hast dieses Mitglied schon als Freund',
	'pp_friend_removed' : 'Freund(e) entfernt',
	'pp_icq_error'      : 'Deine ICQ Nummer muss numerisch sein',
	
	// Friend added:
	'pp_friend_added'     : 'Dein(e) Freund(e) wurde(n) zu deiner Liste hinzugef&uuml;gt!',
	'pp_friend_added_mod' : 'Dein Freund muss deine Anfrage freigeben',
	'pp_friend_approved'  : 'Freundschaftsanfrage freigegeben',
	
	// Comments update
	'pp_comments_updated'  : 'Kommentare aktualisiert',
	'pp_comment_added_mod' : "Kommentar muss freigegeben werden, bevor er angezeigt wird",
	
	// POLL MODULE
	'already_voted' : 'Du hast bereits abgestimmt',
	
	// ARTICLES MODULE
	'rating_updated' : 'Deine Berwertung wurde aktualisiert',
	'rating_added'   : 'Deine Bewertung wurde hinzugef&uuml;gt',
	'rating_already' : 'Du hast diesen Artikel bereits bewertet'
};

/**
* Global stuff
*/

var ipb_global_lang =
{
	// ERROR
	'post_upload_not_empty'   : 'Du hast einen Anhang zum Hochladen. Klicke den HOCHLADEN-Button um es hochzuladen, oder klicke OK um ohne hochladen fortzufahren',
	// EDITORS
	'editor_enter_url'		  : 'Bitte gebe die volle URL ein',
	'editor_enter_title'      : 'Bitte gebe den Titel f&uuml;r dieses Objekt ein',
	'editor_enter_email'      : 'Bitte gebe eine E-Mail-Adresse ein',
	'editor_enter_image'      : 'Bitte gebe die URL f&uuml;r dieses Bild ein',
	'editor_enter_list'       : 'F&uuml;ge ein Listenobjekt hinzu',
	// GENERAL
	'general_error'           : 'Fehler',
	'general_ok'              : 'OK',
	'image_resized'           : 'Bildgr&ouml;&szlig;e verringert: <%1>% der Originalgr&ouml;&szlig;e [ <%2> x <%3> ]',
	'image_attach_percent'    : 'Verkleinert <%1>%',
	'image_attach_no_percent' : 'Bild verkleinert',
	'image_attach_dims'       : '<%1> x <%2>',
	'image_attach_size'       : ' (<%1>)',
	'click_to_view'           : 'Klicken um eine Vollansicht des Bildes zu erhalten',
	'view_full_size'          : 'Bild in Vollansicht ansehen',
	'visit_my_website'		  : 'Besuche meine Homepage'
};