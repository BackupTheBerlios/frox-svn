Version "16 Oct 2007"

******************************************************************************************************

For the English Readme, please see further below.

******************************************************************************************************
JHTAddIn f�r Media Center in Windows Vista Home Premium oder Windows Vista Ultimate
===================================================================================

Von Spyn Doctor


F�r eine genauere Beschreibung von Funktionalit�t, Installation und Benutzung dieses AddIns
(sowie f�r Fragen) gehen Sie bitte zum passenden Unterforum in der deutschen MCE Community:

  http://www.mce-community.de/forum/index.php?showforum=222

Siehe dort den Beitrag "Spyn Doctor's MCE Add-Ins: f�r Vista Media Center"
(der Beitrag ist oben gepinnt).


Aktuell enth�lt das AddIn die folgenden Funktionen, die auch unabh�ngig voneinander (einzeln)
aktiviert werden k�nnen:

- MainBackgroundAddIn : Ein "Background" AddIn (w�hrend der ganzen MCE Session im Hintergrund
                        aktiv) mit aktuell diesen Unterfunktionen:
	- Timeshift-Buffer Sicherung: Erlaubt es w�hrend des Live-TVs den aktuell aufgelaufenen
                        Timeshift-Buffer wie eine aufgezeichnete Sendung zu sichern.
	- Fritz-Box Anrufmonitor : Implementiert einen Anruf-Monitor f�r die Fritz-Box
                        (eingehende Anrufe werden als Dialog im MCE angezeigt)
	- MCEMessage  : Erlaubt es aus externen Prozessen Hinweis-Dialoge im MCE anzuzeigen. 
		        Ein kleines Programm MCEMessage.exe zur Anzeige solcher Dialoge geh�rt 
		        ebenfalls dazu.
		        Funktioniert f�r das eigentliche MCE und bis zu f�nf gleichzeitig
		        laufende Extender (ben�tigt aber die lokale Freigabe gewisser Ports).
	- On-Startup Execute : Erlaubt das automatische Ausf�hren eines Programms beim MCE Start.
	- On-Resume Execute : Erlaubt das automatische Ausf�hren eines Programms wenn der Rechner
                        aus dem Standy "aufgeweckt" wird w�hrend das MCE gerade l�uft.

- Fritz-Box Anruflisten/Telefonbuch : Ein Add-In zur Anzeige der Anruflisten und des Telefonbuches
			einer Fritz-Box, inkl. W�hlhilfe. Erscheint als Icon in der "Programm-
			bibliothek"

- Alben in Wiedergabeliste : Ein Add-In zur Anzeige aller Alben die mit mindestens einem Titel
			auf der ausgew�hlten Wiedergabeliste vertreten sind, mit der M�glichkeit
			ein gew�nschtes Album abzuspielen.

- Diashow Composer    : Ein Add-In zum Zusammenstellen von Diashows. Erscheint als Icon in der
			"Bildbibliothek" auf der "MEHR..." Seite.

- Diashow Settings    : Ein Add-In das in der "Bildbibliothek" auf der "MEHR..." Seite ein Icon
			hinzuf�gt, mit dem man direkt auf die Seite f�r "Diashow Einstellungen"
			gelangt.

- TV-Archivierung     : Ein Add-In zum Verschieben von TV-Aufzeichnungen (auch mehrere auf einmal)
          		in einen vorkonfigurierten Archiv-Ordner. Erscheint als Icon in der
			"Programmbibliothek".


Rechtliches:
============

Das AddIn darf von jedermann f�r jeden Zweck (ob privater oder kommerzieller Natur) frei
verwendet und ver�ndert werden.
Benutzung des Plugins auf eigene Gefahr. Der Autor �bernimmt keinerlei Gew�hrleistung oder 
Haftung f�r evtl. Probleme oder Sch�den die durch die Installation oder Anwendung dieses 
Plugins verursacht werden oder mit diesem in Verbindung stehen, gleich welcher Form.
Durch die Installation und Benutzung entbindet der Nutzer den Autor von jeglichen Anspr�chen
im Zusammenhang mit dem Plugin.



******************************************************************************************************
JHTAddIn for Media Center in Windows Vista Home Premium or Windows Vista Ultimate
=================================================================================

By Spyn Doctor


For a more detailed description of the functionality and how to use and install the add-in,
please visit the matching thread at "The Green Button":

  http://thegreenbutton.com/forums/thread/162083.aspx


Currently the add-in contains the following functions, which can also be activated independently
of each other:

- MainBackgroundAddIn : A "background" add-in (which is active in the background during the whole 
                        MCE session), with currently the following sub-functions:
	- Timeshift-Buffer Backup: Feature to back up the timeshift-buffer while watching Live-TV
                        and save it like a normal recorded show.
        - MCEMessage  : Feature to let an external process display a dialog in MCE.
			A utility program MCEMessage.exe which can be used to show such messages
			is also part of the bundle.
			Works with the actual MCE PC and up to five extenders running at the same
			time (but requires that certain ports are opened locally).
	- On-Startup Execute : Feature to execute an external program at each start of MCE.
	- On-Resume Execute : Feature to execute an external program each time the MCE PC is
                        "waking up" from standby (while the MCE is running).
        - Fritz-Box Call Monitor : Implementation of a phone call monitor for the Fritz-Box
                        hardware (incoming phone calls are shown as dialogs in MCE).

- Albums in Playlist  : An add-in to display and browse all albums which are present with at least
			one title on the currently selected playlist, with the option to start 
			playing a selected album.

- Slideshow Composer  : An add-in to assemble slideshows. Added as an icon on the "MORE..." page of
			the "Picture Library".

- Slideshow Settings  : An add-in which adds an icon on the "MORE..." page of the "Picture Library"
			which sends you directly to the "Slideshow Settings" page.

- TV-Archivation      : An add-in to move recorded shows (even several at once) into a pre-
			configured archive-folder. Added as an icon to the "Program Library".

- Fritz-Box Call-Lists/Phonebook : An Add-In to display the call-lists and phonebook of the Fritz-Box
			hardware, incl. click-to-dial (this add-in is available in German only).


Legal Stuff:
============

The add-in can be used by anone for any purpose (privately or commercially).
Use at your own risk. The author does not accept any liability for any kind of damage or any
other problems caused by the installation and/or usage of the add-in.
By installing and using the add-in you explicitly agree to these terms! Do not use it if
you do not agree!
