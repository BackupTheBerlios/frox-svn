This HLembke directory contains a revised DnsLookup component
by Holger Lembke <holger@hlembke.de> and corresponding NsLookup
project.

This revised DnsLookup component will replace ICS original DnsQuery
component in the future.

francois.piette@overbyte.be

