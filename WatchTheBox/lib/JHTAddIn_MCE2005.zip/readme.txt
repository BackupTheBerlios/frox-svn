Version "10 Dec 2006"

******************************************************************************************************

For the English Readme, please see further below.

******************************************************************************************************
JHTAddIn f�r xpMCE (Windows XP Media Center Edition)
====================================================

Von Spyn Doctor


F�r eine genauere Beschreibung von Funktionalit�t, Installation und Benutzung dieses AddIns
(sowie f�r Fragen) gehen Sie bitte zum passenden Unterforum in der deutschen MCE Community:

  http://www.mce-community.de/forum/index.php?showforum=222

Im ersten (Haupt-)Beitrag in diesem Forum ist alles genau erkl�rt.


Aktuell enth�lt das AddIn die folgenden Funktionen, die auch unabh�ngig voneinander (einzeln)
aktiviert werden k�nnen:

- MainBackgroundAddIn : Ein "Background" AddIn (w�hrend der ganzen MCE Session im Hintegrund
                        aktiv) mit aktuell einer Unterfunktion:
	- Timeshift-Buffer Sicherung: Erlaubt es w�hrend des Live-TVs den aktuell aufgelaufenen
                        Timeshift-Buffer wie eine aufgezeichnete Sendung zu sichern.
	- Fritz-Box Anrufmonitor : Implementiert einen Anruf-Monitor f�r die Fritz-Box
                        (eingehende Anrufe werden als Dialog im MCE angezeigt)
	- MCEMessage  : Erlaubt es aus externen Prozessen Hinweis-Dialoge im MCE anzuzeigen. 
		        Ein kleines Programm MCEMessage.exe zur Anzeige solcher Dialoge geh�rt 
		        ebenfalls dazu.
		        Funktioniert f�r das eigentliche MCE und bis zu f�nf gleichzeitig
		        laufende Extender (ben�tigt aber die lokale Freigabe gewisser Ports).
	- On-Startup Execute : Erlaubt das automatische Ausf�hren eines Programms beim MCE Start.
	- On-Resume Execute : Erlaubt das automatische Ausf�hren eines Programms wenn der Rechner
                        aus dem Standy "aufgeweckt" wird w�hrend das MCE gerade l�uft.

- SlideshowSettings   : F�gt unter "Eigene Bilder" einen Men�eintrag hinzu, mit dem
                        man direkt auf die Seite f�r "Diaschau Einstellungen" gelangt.

- TV-Archivierung     : F�gt unter "Mehr Programme" einen neuen Eintrag hinzu mit dem man
                        TV-Aufzeichnungen (auch mehrere auf einmal) in einen vorkonfigurierten
                        Archiv-Ordner verschieben kann.


Rechtliches:
============

Das AddIn darf von jedermann f�r jeden Zweck (ob privater oder kommerzieller Natur) frei
verwendet und ver�ndert werden.
Benutzung des Plugins auf eigene Gefahr. Der Autor �bernimmt keinerlei Gew�hrleistung oder 
Haftung f�r evtl. Probleme oder Sch�den die durch die Installation oder Anwendung dieses 
Plugins verursacht werden oder mit diesem in Verbindung stehen, gleich welcher Form.
Durch die Installation und Benutzung entbindet der Nutzer den Autor von jeglichen Anspr�chen
im Zusammenhang mit dem Plugin.



******************************************************************************************************
JHTAddIn for xpMCE (Windows XP Media Center Edition)
====================================================

By Spyn Doctor


For a more detailed description of the functionality and how to use and install the add-in,
please visit the matching thread at "The Green Button":

  http://thegreenbutton.com/forums/thread/148493.aspx


Currently the add-in contains the following functions, which can also be activated independently
of each other:

- MainBackgroundAddIn : A "background" add-in (which is active in the background during the whole 
                        MCE session), with currently the following sub-functions:
	- Timeshift-Buffer Backup: Feature to back up the timeshift-buffer while watching Live-TV
                        and save it like a normal recorded show.
        - MCEMessage  : Feature to let an external process display a dialog in MCE.
			A utility program MCEMessage.exe which can be used to show such messages
			is also part of the bundle.
			Works with the actual MCE PC and up to five extenders running at the same
			time (but requires that certain ports are opened locally).
	- On-Startup Execute : Feature to execute an external program at each start of MCE.
	- On-Resume Execute : Feature to execute an external program each time the MCE PC is
                        "waking up" from standby (while the MCE is running).
        - Fritz-Box Call Monitor : Implementation of a phone call monitor for the Fritz-Box
                        hardware (incoming phone calls are shown as dialogs in MCE).

- SlideshowSettings   : An add-in that adds a new menu entry under "My Pictures", which allows you
                        to immediately go to the "Slideshow Settings" page.

- TV-Archivierung     : An add-in that adds a new entry under "More Programs", which allows you to
                        move recorded shows (several at once) into a pre-configured archive-folder.


Legal Stuff:
============

The add-in can be used by anone for any purpose (privately or commercially).
Use at your own risk. The author does not accept any liability for any kind of damage or any
other problems caused by the installation and/or usage of the add-in.
By installing and using the add-in you explicitly agree to these terms! Do not use it if
you do not agree!
